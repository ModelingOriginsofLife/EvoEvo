#!/bin/bash

rm -rf ../build/bin/*
rm -rf CMakeFiles
rm cmake_install.cmake
rm CMakeCache.txt
rm Config.h
rm libEvoEvo.a
rm Makefile
